from gripcontrol import HttpStreamFormat
from faas_grip import publish

def handler(event, context):

	publish('mychannel', HttpStreamFormat('some data\n'))