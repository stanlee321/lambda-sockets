from gripcontrol import WebSocketMessageFormat
from faas_grip import lambda_get_websocket, publish

def handler(event, context):
	from gripcontrol import HttpStreamFormat
	from faas_grip import publish

	publish('room', HttpStreamFormat('some data\n'))

